# InterSlop

A fork of [Inter](https://github.com/rsms/inter) where the em dash (—) and en dash (–) render as the word "slop" in small letters.

For when AI-slop landing pages cannot stop typing em dashes — and you want the H1 to confess.

## Install
- macOS: double-click any `.ttf` → "Install Font", or drop the folder into Font Book.
- Windows: right-click any `.ttf` → Install for all users.
- Linux: copy `.ttf` files into `~/.local/share/fonts/` and run `fc-cache -f -v`.
- Web: copy the `.ttf` and serve it with `@font-face { font-family: "Inter Slop"; src: url("InterSlop-Regular.ttf"); }`.

## What's modified
- U+2014 EM DASH → "slop" (lowercase, scaled to fit the em dash advance width)
- U+2013 EN DASH → "slop" (scaled to fit the narrower en dash advance width)

Everything else is untouched Inter.

## Weights
Thin, ExtraLight, Light, Regular, Medium, SemiBold, Bold, ExtraBold, Black — each with an Italic. 18 faces total.

## License
Inherits Inter's SIL Open Font License 1.1 — see `LICENSE-Inter.txt`.
